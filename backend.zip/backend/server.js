const express = require("express");
const cors = require("cors");
require("dotenv").config();

const accountRoutes = require("./routes/accountRoutes");
const transactionRoutes = require("./routes/transactionRoutes");
const investmentRoutes = require("./routes/investmentRoutes");
const loanRoutes = require("./routes/loanRoutes");
const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes"); // Add this line
const categoryRoutes = require("./routes/categoryRoutes"); // Add this line

const app = express();
app.use(express.json());
app.use(cors());

// Register API routes
app.use("/api/accounts", accountRoutes);
app.use("/api/transactions", transactionRoutes);
app.use("/api/investments", investmentRoutes);
app.use("/api/loans", loanRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes); // Add this line
app.use("/api/categories", categoryRoutes); // Add this line

// Default route
app.get("/", (req, res) => {
    res.json({ message: "Financial Tracker API is running!" });
});

// Catch-all for non-existing routes
app.use((req, res) => {
    res.status(404).json({ error: "Route not found" });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
