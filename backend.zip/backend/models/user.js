const pool = require("../database");

const User = {
    getAll: (callback) => {
        pool.query("SELECT * FROM users", callback);
    },

    getById: (id, callback) => {
        pool.query("SELECT * FROM users WHERE id = ?", [id], callback);
    },

    create: (data, callback) => {
        pool.query("INSERT INTO users SET ?", data, callback);
    },

    update: (id, data, callback) => {
        pool.query("UPDATE users SET ? WHERE id = ?", [data, id], callback);
    },

    delete: (id, callback) => {
        pool.query("DELETE FROM users WHERE id = ?", [id], callback);
    }
};

module.exports = User;
