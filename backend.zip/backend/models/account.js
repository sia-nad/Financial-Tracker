const pool = require("../database");

const Account = {
    getAll: (callback) => {
        pool.query("SELECT * FROM accounts", callback);
    },

    getById: (id, callback) => {
        pool.query("SELECT * FROM accounts WHERE id = ?", [id], callback);
    },

    create: (data, callback) => {
        pool.query("INSERT INTO accounts SET ?", data, callback);
    },

    update: (id, data, callback) => {
        pool.query("UPDATE accounts SET ? WHERE id = ?", [data, id], callback);
    },

    delete: (id, callback) => {
        pool.query("DELETE FROM accounts WHERE id = ?", [id], callback);
    }
};

module.exports = Account;
