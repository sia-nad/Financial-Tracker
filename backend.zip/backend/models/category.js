const pool = require("../database");

const Category = {
    getAll: (callback) => {
        pool.query("SELECT * FROM categories", callback);
    },

    getById: (id, callback) => {
        pool.query("SELECT * FROM categories WHERE id = ?", [id], callback);
    },

    create: (data, callback) => {
        pool.query("INSERT INTO categories SET ?", data, callback);
    },

    update: (id, data, callback) => {
        pool.query("UPDATE categories SET ? WHERE id = ?", [data, id], callback);
    },

    delete: (id, callback) => {
        pool.query("DELETE FROM categories WHERE id = ?", [id], callback);
    }
};

module.exports = Category;
