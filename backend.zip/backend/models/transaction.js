const pool = require("../database");

const Transaction = {
    getAll: (callback) => {
        pool.query("SELECT * FROM transactions", callback);
    },

    getById: (id, callback) => {
        pool.query("SELECT * FROM transactions WHERE id = ?", [id], callback);
    },

    create: (data, callback) => {
        pool.query("INSERT INTO transactions SET ?", data, callback);
    },

    update: (id, data, callback) => {
        pool.query("UPDATE transactions SET ? WHERE id = ?", [data, id], callback);
    },

    delete: (id, callback) => {
        pool.query("DELETE FROM transactions WHERE id = ?", [id], callback);
    }
};

module.exports = Transaction;
