const express = require("express");
const Investment = require("../models/investment");
const router = express.Router();

// Get all investments
router.get("/", (req, res) => {
    Investment.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

// Get a specific investment by ID
router.get("/:id", (req, res) => {
    Investment.getById(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Create a new investment
router.post("/", (req, res) => {
    Investment.create(req.body, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Investment added", id: result.insertId });
    });
});

// Delete an investment by ID
router.delete("/:id", (req, res) => {
    Investment.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Investment deleted" });
    });
});

module.exports = router;
