const express = require("express");
const Transaction = require("../models/transaction");
const router = express.Router();

// Get all transactions
router.get("/", (req, res) => {
    Transaction.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

// Get a specific transaction by ID
router.get("/:id", (req, res) => {
    Transaction.getById(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Create a new transaction
router.post("/", (req, res) => {
    Transaction.create(req.body, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Transaction added", id: result.insertId });
    });
});

// Delete a transaction by ID
router.delete("/:id", (req, res) => {
    Transaction.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Transaction deleted" });
    });
});

module.exports = router;

