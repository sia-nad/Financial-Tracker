const express = require("express");
const Category = require("../models/category");
const router = express.Router();

// Get all categories
router.get("/", (req, res) => {
    Category.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

// Get a specific category by ID
router.get("/:id", (req, res) => {
    Category.getById(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Create a new category
router.post("/", (req, res) => {
    Category.create(req.body, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Category added", id: result.insertId });
    });
});

// Delete a category by ID
router.delete("/:id", (req, res) => {
    Category.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Category deleted" });
    });
});

module.exports = router;
