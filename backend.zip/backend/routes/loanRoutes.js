const express = require("express");
const Loan = require("../models/loan");
const router = express.Router();

// Get all loans
router.get("/", (req, res) => {
    Loan.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

// Get a specific loan by ID
router.get("/:id", (req, res) => {
    Loan.getById(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Create a new loan
router.post("/", (req, res) => {
    Loan.create(req.body, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Loan added", id: result.insertId });
    });
});

// Delete a loan by ID
router.delete("/:id", (req, res) => {
    Loan.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Loan deleted" });
    });
});

module.exports = router;


