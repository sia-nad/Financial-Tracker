const express = require("express");
const User = require("../models/user");
const router = express.Router();

// Get all users
router.get("/", (req, res) => {
    User.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

// Get a specific user by ID
router.get("/:id", (req, res) => {
    User.getById(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Register a new user
router.post("/", (req, res) => {
    const { name, email, password } = req.body;
    // You can hash the password before storing it in the database
    User.create({ name, email, password }, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "User registered", id: result.insertId });
    });
});

// Delete a user by ID
router.delete("/:id", (req, res) => {
    User.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "User deleted" });
    });
});

module.exports = router;
