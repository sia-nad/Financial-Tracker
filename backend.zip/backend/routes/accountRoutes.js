const express = require("express");
const Account = require("../models/account");
const router = express.Router();

// Get all accounts
router.get("/", (req, res) => {
    Account.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

// Get a specific account by ID
router.get("/:id", (req, res) => {
    Account.getById(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Create a new account
router.post("/", (req, res) => {
    Account.create(req.body, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Account added", id: result.insertId });
    });
});

// Delete an account by ID
router.delete("/:id", (req, res) => {
    Account.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Account deleted" });
    });
});

module.exports = router;
