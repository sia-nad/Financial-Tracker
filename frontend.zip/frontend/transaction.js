// Calendar functionality
function initCalendar() {
    const calendarDays = document.querySelector('.calendar-days');
    const date = new Date();
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    
    // Add empty days for padding
    for (let i = 0; i < firstDay.getDay(); i++) {
        const emptyDay = document.createElement('div');
        emptyDay.className = 'calendar-day';
        calendarDays.appendChild(emptyDay);
    }

    // Add actual days
    for (let i = 1; i <= lastDay.getDate(); i++) {
        const day = document.createElement('div');
        day.className = 'calendar-day';
        if (i === date.getDate()) day.classList.add('today');
        if (hasTransactions(i)) day.classList.add('has-transaction');
        day.textContent = i;
        
        day.addEventListener('mouseover', (e) => showTransactionPreview(e, i));
        day.addEventListener('mouseout', hideTransactionPreview);
        
        calendarDays.appendChild(day);
    }
}

function showTransactionPreview(event, day) {
    const transactions = getTransactionsForDay(day);
    if (!transactions.length) return;

    const preview = document.createElement('div');
    preview.className = 'transaction-preview';
    preview.innerHTML = `
        <h4>Transactions for ${day}</h4>
        ${transactions.map(t => `
            <div class="preview-item">
                <span>${t.description}</span>
                <span>₹${t.amount}</span>
            </div>
        `).join('')}
    `;

    event.target.appendChild(preview);
    preview.style.display = 'block';
}

function hideTransactionPreview() {
    const preview = document.querySelector('.transaction-preview');
    if (preview) preview.remove();
}

// Initialize calendar when page loads
document.addEventListener('DOMContentLoaded', initCalendar);