// Initialize Charts
document.addEventListener('DOMContentLoaded', function() {
    initializeCategoryCharts();
    loadCategories();
});

function initializeCategoryCharts() {
    // Monthly Spending Chart
    const spendingCtx = document.getElementById('categoryChart').getContext('2d');
    new Chart(spendingCtx, {
        type: 'bar',
        data: {
            labels: ['Food', 'Transport', 'Housing', 'Entertainment', 'Shopping'],
            datasets: [{
                label: 'Monthly Spending',
                data: [15000, 8000, 25000, 5000, 12000],
                backgroundColor: [
                    'rgba(255, 107, 107, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)'
                ]
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: 'white' }
                },
                x: {
                    ticks: { color: 'white' }
                }
            },
            plugins: {
                legend: {
                    labels: { color: 'white' }
                }
            }
        }
    });

    // Distribution Chart
    const distributionCtx = document.getElementById('distributionChart').getContext('2d');
    new Chart(distributionCtx, {
        type: 'doughnut',
        data: {
            labels: ['Food', 'Transport', 'Housing', 'Entertainment', 'Shopping'],
            datasets: [{
                data: [23, 12, 38, 8, 19],
                backgroundColor: [
                    'rgba(255, 107, 107, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: 'white' }
                }
            }
        }
    });
}

// Category Management
function loadCategories() {
    // Fetch categories from database and render
    const categories = [
        { id: 1, name: 'Food & Dining', icon: 'utensils', color: '#FF6B6B', spending: 15000 },
        { id: 2, name: 'Transport', icon: 'car', color: '#4ECDC4', spending: 8000 },
        // Add more categories
    ];

    const categoryGrid = document.querySelector('.category-grid');
    categoryGrid.innerHTML = categories.map(category => createCategoryCard(category)).join('');
    updateCategoryStats(categories);
}

function createCategoryCard(category) {
    return `
        <div class="category-card" data-id="${category.id}">
            <div class="category-icon" style="background: linear-gradient(135deg, ${category.color}, ${adjustColor(category.color, 30)})">
                <i class="fas fa-${category.icon}"></i>
            </div>
            <div class="category-details">
                <h3>${category.name}</h3>
                <p>₹${category.spending.toLocaleString()} this month</p>
                <div class="usage-bar">
                    <div class="progress" style="width: ${calculateUsagePercentage(category.spending)}%"></div>
                </div>
            </div>
            <div class="category-actions">
                <button class="btn-icon" onclick="editCategory(${category.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon" onclick="deleteCategory(${category.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;
}

// Modal Handling
function openNewCategoryModal() {
    const modal = document.getElementById('categoryModal');
    modal.style.display = 'block';
    resetCategoryForm();
}

function closeCategoryModal() {
    const modal = document.getElementById('categoryModal');
    modal.style.display = 'none';
}

// Form Handling
document.querySelector('.category-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = {
        name: this.querySelector('input[name="category_name"]').value,
        icon: this.querySelector('.icon-option.selected i').className.split(' ')[1].split('-')[1],
        color: this.querySelector('input[type="color"]').value
    };
    
    saveCategory(formData);
    closeCategoryModal();
});

// Icon Selection
document.querySelectorAll('.icon-option').forEach(option => {
    option.addEventListener('click', function() {
        document.querySelectorAll('.icon-option').forEach(opt => opt.classList.remove('selected'));
        this.classList.add('selected');
    });
});

// Utility Functions
function calculateUsagePercentage(spending) {
    const maxBudget = 30000; // Example budget limit
    return Math.min((spending / maxBudget) * 100, 100);
}

function adjustColor(hex, percent) {
    // Function to adjust color brightness
    const num = parseInt(hex.replace('#', ''), 16);
    const amt = Math.round(2.55 * percent);
    const R = (num >> 16) + amt;
    const G = (num >> 8 & 0x00FF) + amt;
    const B = (num & 0x0000FF) + amt;
    return `#${(1 << 24 | (R < 255 ? R < 1 ? 0 : R : 255) << 16 | (G < 255 ? G < 1 ? 0 : G : 255) << 8 | (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1)}`;
}

function updateCategoryStats(categories) {
    const totalCategories = categories.length;
    const mostUsed = categories.reduce((a, b) => b.spending > a.spending ? b : a);
    const highestSpend = categories.reduce((a, b) => b.spending > a.spending ? b : a);

    document.querySelector('.category-stats').innerHTML = `
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-tags"></i>
            </div>
            <div class="stat-info">
                <h3>Total Categories</h3>
                <p>${totalCategories}</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-chart-pie"></i>
            </div>
            <div class="stat-info">
                <h3>Most Used</h3>
                <p>${mostUsed.name}</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-info">
                <h3>Highest Spend</h3>
                <p>${highestSpend.name}</p>
            </div>
        </div>
    `;
}

// CRUD Operations
async function saveCategory(categoryData) {
    try {
        // API call to save category
        const response = await fetch('/api/categories', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(categoryData)
        });
        
        if (response.ok) {
            loadCategories(); // Refresh the list
        }
    } catch (error) {
        console.error('Error saving category:', error);
    }
}

async function deleteCategory(categoryId) {
    if (confirm('Are you sure you want to delete this category?')) {
        try {
            // API call to delete category
            const response = await fetch(`/api/categories/${categoryId}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                loadCategories(); // Refresh the list
            }
        } catch (error) {
            console.error('Error deleting category:', error);
        }
    }
}

function editCategory(categoryId) {
    // Fetch category details and open modal with pre-filled data
    const category = categories.find(c => c.id === categoryId);
    if (category) {
        openNewCategoryModal();
        fillCategoryForm(category);
    }
}