function handleLogin(event) {
    event.preventDefault(); // Prevent form submission

    // Get input values
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    // Sample credentials (update for real authentication)
    const validUsername = "admin";
    const validPassword = "password123";

    // Check credentials
    if (username === validUsername && password === validPassword) {
        alert("Login successful!");
        window.location.href = "dashboard.html"; // Redirect to the next page
    } else {
        alert("Invalid username or password. Please try again.");
    }
}
