document.addEventListener('DOMContentLoaded', function() {
    loadAccounts();
    updateAccountsSummary();
});

async function loadAccounts() {
    // Example accounts data (replace with API call)
    const accounts = {
        savings: [
            {
                id: 1,
                bankName: 'HDFC Bank',
                accountNumber: 'XXXX1234',
                balance: 150000,
                type: 'savings'
            },
            {
                id: 2,
                bankName: 'SBI',
                accountNumber: 'XXXX5678',
                balance: 100000,
                type: 'savings'
            }
        ],
        credit: [
            {
                id: 1,
                bankName: 'HDFC Bank',
                cardNumber: 'XXXX XXXX XXXX 4321',
                creditLimit: 200000,
                dueDate: '2024-02-15',
                outstandingAmount: 45000,
                type: 'credit'
            }
            // More credit cards...
        ]
    };

    renderAccounts(accounts);
}

function renderAccounts(accounts) {
    // Render Savings Accounts
    const accountsGrid = document.querySelector('.accounts-grid');
    accountsGrid.innerHTML = accounts.savings.map(account => `
        <div class="account-card">
            <div class="account-header">
                <div class="bank-logo">
                    <i class="fas fa-university"></i>
                </div>
                <h3>${account.bankName}</h3>
            </div>
            <div class="account-details">
                <div class="detail-row">
                    <span>Account Number</span>
                    <span>${account.accountNumber}</span>
                </div>
                <div class="detail-row">
                    <span>Current Balance</span>
                    <span class="amount">₹${formatNumber(account.balance)}</span>
                </div>
                <div class="detail-row">
                    <span>Account Type</span>
                    <span>Savings</span>
                </div>
            </div>
            <div class="account-actions">
                <button class="btn-icon" onclick="editAccount(${account.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon" onclick="deleteAccount(${account.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');

    // Render Credit Cards
    const creditCardsGrid = document.querySelector('.credit-cards-grid');
    creditCardsGrid.innerHTML = accounts.credit.map(card => `
        <div class="credit-card">
            <div class="card-brand">
                <i class="fab fa-cc-visa"></i>
            </div>
            <div class="card-chip"></div>
            <div class="card-number">${card.cardNumber}</div>
            <div class="card-footer">
                <div class="card-holder">${card.bankName}</div>
                <div class="card-expiry">Due: ${formatDate(card.dueDate)}</div>
            </div>
            <div class="account-details">
                <div class="detail-row">
                    <span>Credit Limit</span>
                    <span>₹${formatNumber(card.creditLimit)}</span>
                </div>
                <div class="detail-row">
                    <span>Outstanding</span>
                    <span>₹${formatNumber(card.outstandingAmount)}</span>
                </div>
            </div>
            <div class="account-actions">
                <button class="btn-icon" onclick="editCard(${card.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon" onclick="deleteCard(${card.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

// Modal Handling
function openNewAccountModal() {
    const modal = document.getElementById('accountModal');
    modal.style.display = 'block';
    resetForm();
}

function closeAccountModal() {
    const modal = document.getElementById('accountModal');
    modal.style.display = 'none';
}

function toggleAccountFields() {
    const type = document.querySelector('select[name="account_type"]').value;
    const savingsFields = document.querySelectorAll('.savings-field');
    const creditFields = document.querySelectorAll('.credit-field');

    savingsFields.forEach(field => {
        field.style.display = type === 'savings' ? 'block' : 'none';
    });
    creditFields.forEach(field => {
        field.style.display = type === 'credit' ? 'block' : 'none';
    });
}

// Form Handling
document.querySelector('.account-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        type: this.querySelector('select[name="account_type"]').value,
        bankName: this.querySelector('input[name="bank_name"]').value,
        accountNumber: this.querySelector('input[name="account_number"]').value,
        ...(this.querySelector('select[name="account_type"]').value === 'savings' 
            ? { balance: parseFloat(this.querySelector('input[name="balance"]').value) }
            : {
                creditLimit: parseFloat(this.querySelector('input[name="credit_limit"]').value),
                dueDate: this.querySelector('input[name="due_date"]').value
            }
        )
    };

    await saveAccount(formData);
    closeAccountModal();
    loadAccounts();
});

async function saveAccount(accountData) {
    try {
        const response = await fetch('/api/accounts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(accountData)
        });
        
        if (!response.ok) throw new Error('Failed to save account');
        
        updateAccountsSummary();
        return await response.json();
    } catch (error) {
        console.error('Error saving account:', error);
        alert('Failed to save account. Please try again.');
    }
}

async function deleteAccount(accountId) {
    if (confirm('Are you sure you want to delete this account?')) {
        try {
            const response = await fetch(`/api/accounts/${accountId}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) throw new Error('Failed to delete account');
            
            loadAccounts();
            updateAccountsSummary();
        } catch (error) {
            console.error('Error deleting account:', error);
            alert('Failed to delete account. Please try again.');
        }
    }
}

function updateAccountsSummary() {
    // Calculate and update summary statistics
    const summary = calculateAccountsSummary();
    
    document.querySelector('.accounts-summary').innerHTML = `
        <div class="summary-card">
            <div class="summary-icon">
                <i class="fas fa-university"></i>
            </div>
            <div class="summary-info">
                <h3>Total Balance</h3>
                <p class="amount">₹${formatNumber(summary.totalBalance)}</p>
            </div>
        </div>
        <div class="summary-card">
            <div class="summary-icon">
                <i class="fas fa-credit-card"></i>
            </div>
            <div class="summary-info">
                <h3>Credit Cards</h3>
                <p>${summary.creditCards} Active</p>
            </div>
        </div>
        <div class="summary-card">
            <div class="summary-icon">
                <i class="fas fa-wallet"></i>
            </div>
            <div class="summary-info">
                <h3>Savings Accounts</h3>
                <p>${summary.savingsAccounts} Active</p>
            </div>
        </div>
    `;
}

// Utility Functions
function formatNumber(num) {
    return num.toLocaleString('en-IN');
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

function calculateAccountsSummary() {
    // Replace with actual calculations from your data
    return {
        totalBalance: 250000,
        creditCards: 3,
        savingsAccounts: 2
    };
}

function resetForm() {
    document.querySelector('.account-form').reset();
    toggleAccountFields();
}