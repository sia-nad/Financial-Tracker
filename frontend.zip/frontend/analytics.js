document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    loadAnalytics();

    // Handle time range changes
    document.getElementById('timeRange').addEventListener('change', function() {
        loadAnalytics(this.value);
    });
});

function initializeCharts() {
    // Income vs Expenses Chart
    const incomeExpenseCtx = document.getElementById('incomeExpenseChart').getContext('2d');
    new Chart(incomeExpenseCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Income',
                data: [75000, 82000, 85000, 80000, 85000, 90000],
                borderColor: '#4CAF50',
                tension: 0.4,
                fill: false
            }, {
                label: 'Expenses',
                data: [45000, 48000, 42000, 46000, 45000, 47000],
                borderColor: '#f44336',
                tension: 0.4,
                fill: false
            }]
        },
        options: getChartOptions('Income vs Expenses Trend')
    });

    // Category Distribution Chart
    const categoryCtx = document.getElementById('categoryChart').getContext('2d');
    new Chart(categoryCtx, {
        type: 'doughnut',
        data: {
            labels: ['Housing', 'Food', 'Transport', 'Utilities', 'Entertainment'],
            datasets: [{
                data: [35, 25, 15, 15, 10],
                backgroundColor: [
                    '#4CAF50',
                    '#2196F3',
                    '#FFC107',
                    '#9C27B0',
                    '#FF5722'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: 'white' }
                }
            }
        }
    });

    // Savings Progress Chart
    const savingsCtx = document.getElementById('savingsChart').getContext('2d');
    new Chart(savingsCtx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Monthly Savings',
                data: [30000, 34000, 43000, 34000, 40000, 43000],
                backgroundColor: '#4CAF50'
            }]
        },
        options: getChartOptions('Monthly Savings Trend')
    });

    // Portfolio Performance Chart
    const portfolioCtx = document.getElementById('portfolioChart').getContext('2d');
    new Chart(portfolioCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Portfolio Value',
                data: [450000, 470000, 465000, 490000, 485000, 500000],
                borderColor: '#2196F3',
                tension: 0.4,
                fill: true,
                backgroundColor: 'rgba(33, 150, 243, 0.1)'
            }]
        },
        options: getChartOptions('Portfolio Value Trend')
    });
}

function getChartOptions(title) {
    return {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: { color: 'white' },
                grid: { color: 'rgba(255, 255, 255, 0.1)' }
            },
            x: {
                ticks: { color: 'white' },
                grid: { color: 'rgba(255, 255, 255, 0.1)' }
            }
        },
        plugins: {
            legend: {
                labels: { color: 'white' }
            },
            title: {
                display: true,
                text: title,
                color: 'white'
            }
        }
    };
}

async function loadAnalytics(timeRange = 30) {
    try {
        // Replace with actual API call
        const response = await fetch(`/api/analytics?timeRange=${timeRange}`);
        const data = await response.json();
        updateMetrics(data);
        updateCharts(data);
        updateLoanAnalysis(data.loans);
        updateInvestmentAnalysis(data.investments);
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

function updateMetrics(data) {
    // Update key metrics with comparison to previous period
    updateMetricCard('income', {
        current: data.totalIncome,
        previous: data.previousIncome,
        trend: calculateTrend(data.totalIncome, data.previousIncome)
    });

    updateMetricCard('expenses', {
        current: data.totalExpenses,
        previous: data.previousExpenses,
        trend: calculateTrend(data.totalExpenses, data.previousExpenses)
    });

    updateMetricCard('savings', {
        current: calculateSavingsRate(data.totalIncome, data.totalExpenses),
        previous: calculateSavingsRate(data.previousIncome, data.previousExpenses),
        trend: calculateTrend(data.savingsRate, data.previousSavingsRate)
    });
}

function updateMetricCard(type, data) {
    const card = document.querySelector(`.metric-card.${type}`);
    if (!card) return;

    const amount = card.querySelector('.amount');
    const trend = card.querySelector('.trend');
    
    amount.textContent = formatCurrency(data.current);
    trend.textContent = `${data.trend >= 0 ? '+' : ''}${data.trend.toFixed(1)}% vs last period`;
    trend.className = `trend ${data.trend >= 0 ? 'positive' : 'negative'}`;
}

function updateLoanAnalysis(loanData) {
    const totalLoan = document.querySelector('.loan-metric-card:nth-child(1) .amount');
    const monthlyEMI = document.querySelector('.loan-metric-card:nth-child(2) .amount');
    const interestPaid = document.querySelector('.loan-metric-card:nth-child(3) .amount');

    totalLoan.textContent = formatCurrency(loanData.totalAmount);
    monthlyEMI.textContent = formatCurrency(loanData.monthlyEMI);
    interestPaid.textContent = formatCurrency(loanData.interestPaid);

    // Update progress bar
    const progressBar = document.querySelector('.progress');
    progressBar.style.width = `${loanData.progressPercentage}%`;
}

function updateInvestmentAnalysis(investmentData) {
    const portfolioValue = document.querySelector('.investment-metric-card:nth-child(1) .amount');
    const bestPerforming = document.querySelector('.investment-metric-card:nth-child(2) p');
    const monthlySIP = document.querySelector('.investment-metric-card:nth-child(3) .amount');

    portfolioValue.textContent = formatCurrency(investmentData.totalValue);
    bestPerforming.textContent = investmentData.bestPerforming.name;
    monthlySIP.textContent = formatCurrency(investmentData.monthlySIP);
}

// Utility Functions
function calculateTrend(current, previous) {
    return ((current - previous) / previous) * 100;
}

function calculateSavingsRate(income, expenses) {
    return ((income - expenses) / income) * 100;
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(amount);
}

function formatPercentage(value) {
    return `${value.toFixed(1)}%`;
}