// Loan calculations and display
class LoanCalculator {
    static calculateEMI(principal, rate, tenure) {
        const monthlyRate = (rate / 100) / 12;
        const months = tenure * 12;
        const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / 
                   (Math.pow(1 + monthlyRate, months) - 1);
        return Math.round(emi);
    }

    static generateAmortizationSchedule(principal, rate, tenure) {
        const monthlyRate = (rate / 100) / 12;
        const months = tenure * 12;
        const emi = this.calculateEMI(principal, rate, tenure);
        const schedule = [];
        let balance = principal;

        for (let i = 1; i <= months; i++) {
            const interest = balance * monthlyRate;
            const principal = emi - interest;
            balance -= principal;

            schedule.push({
                date: new Date(Date.now() + (i * 30 * 24 * 60 * 60 * 1000)),
                emi: emi,
                principal: Math.round(principal),
                interest: Math.round(interest),
                balance: Math.round(balance)
            });
        }
        return schedule;
    }
}

// Modal Handling
function openNewLoanModal() {
    const modal = document.getElementById('newLoanModal');
    modal.style.display = 'block';
}

function closeNewLoanModal() {
    const modal = document.getElementById('newLoanModal');
    modal.style.display = 'none';
}

function showLoanDetails(loanId) {
    const modal = document.getElementById('loanDetailsModal');
    const schedule = document.querySelector('.payment-schedule tbody');
    schedule.innerHTML = ''; // Clear existing schedule

    // Fetch loan details (replace with actual API call)
    const loanDetails = {
        id: loanId,
        principal: 400000,
        rate: 8.5,
        tenure: 5
    };

    // Generate and display amortization schedule
    const scheduleData = LoanCalculator.generateAmortizationSchedule(
        loanDetails.principal,
        loanDetails.rate,
        loanDetails.tenure
    );

    scheduleData.forEach(row => {
        schedule.innerHTML += `
            <tr>
                <td>${row.date.toLocaleDateString()}</td>
                <td>₹${row.emi.toLocaleString()}</td>
                <td>₹${row.principal.toLocaleString()}</td>
                <td>₹${row.interest.toLocaleString()}</td>
                <td>₹${row.balance.toLocaleString()}</td>
            </tr>
        `;
    });

    modal.style.display = 'block';
}

// Form Handling
document.querySelector('.loan-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = {
        type: this.querySelector('select[name="type"]').value,
        amount: parseFloat(this.querySelector('input[name="amount"]').value),
        rate: parseFloat(this.querySelector('input[name="rate"]').value),
        tenure: parseInt(this.querySelector('input[name="tenure"]').value),
        bank: this.querySelector('select[name="bank"]').value,
        startDate: this.querySelector('input[name="startDate"]').value
    };

    // Calculate EMI
    const emi = LoanCalculator.calculateEMI(formData.amount, formData.rate, formData.tenure);
    
    // Add new loan card to the grid
    const loansGrid = document.querySelector('.loans-grid');
    loansGrid.insertAdjacentHTML('afterbegin', `
        <div class="loan-card" onclick="showLoanDetails(${Date.now()})">
            <div class="loan-header">
                <div class="loan-type">
                    <i class="fas fa-${getLoanIcon(formData.type)}"></i>
                    <span>${formData.type} Loan</span>
                </div>
                <div class="loan-status ongoing">Ongoing</div>
            </div>
            <div class="loan-amount">₹${formData.amount.toLocaleString()}</div>
            <div class="loan-progress">
                <div class="progress-bar">
                    <div class="progress" style="width: 0%"></div>
                </div>
                <span>0% paid</span>
            </div>
            <div class="loan-details">
                <div class="detail-item">
                    <span>EMI</span>
                    <span>₹${emi.toLocaleString()}</span>
                </div>
                <div class="detail-item">
                    <span>Interest Rate</span>
                    <span>${formData.rate}%</span>
                </div>
            </div>
        </div>
    `);

    closeNewLoanModal();
});

// Utility Functions
function getLoanIcon(type) {
    const icons = {
        home: 'home',
        personal: 'user',
        car: 'car',
        education: 'graduation-cap'
    };
    return icons[type] || 'money-bill';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }
}

// Initialize tooltips and other UI elements
document.addEventListener('DOMContentLoaded', function() {
    // Update loan summaries
    updateLoanSummaries();
    
    // Add event listeners for filter changes
    document.querySelectorAll('.filter-select').forEach(select => {
        select.addEventListener('change', filterLoans);
    });
});

function updateLoanSummaries() {
    // Calculate and update total loans, EMIs, and interest paid
    // This would typically fetch data from your backend
    const totalLoans = calculateTotalLoans();
    const monthlyEMI = calculateTotalEMI();
    const interestPaid = calculateInterestPaid();

    // Update the summary cards
    document.querySelector('.loan-summary').innerHTML = `
        <div class="summary-card">
            <h3>Total Active Loans</h3>
            <p class="amount">₹${totalLoans.toLocaleString()}</p>
            <span class="sub-text">Across ${countActiveLoans()} loans</span>
        </div>
        <div class="summary-card">
            <h3>Monthly EMI</h3>
            <p class="amount">₹${monthlyEMI.toLocaleString()}</p>
            <span class="sub-text">Next due: ${getNextEMIDate()}</span>
        </div>
        <div class="summary-card">
            <h3>Interest Paid</h3>
            <p class="amount">₹${interestPaid.toLocaleString()}</p>
            <span class="sub-text">This year</span>
        </div>
    `;
}

// Add this script tag to your loans.html
// <script src="loans.js"></script>