// Initialize page data
document.addEventListener('DOMContentLoaded', function() {
    loadInvestments();
    updatePortfolioSummary();
});

// Load investments data
async function loadInvestments() {
    // Example investment data (replace with API call)
    const investments = {
        mutual_funds: [
            {
                id: 1,
                name: 'HDFC Mid-Cap Opportunities Fund',
                type: 'Growth',
                purchaseDate: '2023-01-15',
                investedAmount: 100000,
                currentValue: 112500,
                returns: 12.5
            },
            // More mutual funds...
        ],
        stocks: [
            {
                id: 1,
                name: 'Reliance Industries',
                purchaseDate: '2023-03-10',
                quantity: 50,
                purchasePrice: 2000,
                currentValue: 120000,
                returns: 20
            },
            // More stocks...
        ]
    };

    renderInvestments(investments);
}

function renderInvestments(investments) {
    // Render Mutual Funds
    const mutualFundsGrid = document.querySelector('#mutual-funds .investment-grid');
    mutualFundsGrid.innerHTML = investments.mutual_funds.map(fund => `
        <div class="investment-card">
            <div class="investment-header">
                <h3>${fund.name}</h3>
                <span class="badge growth">${fund.type}</span>
            </div>
            <div class="investment-details">
                <div class="detail-row">
                    <span>Purchase Date</span>
                    <span>${formatDate(fund.purchaseDate)}</span>
                </div>
                <div class="detail-row">
                    <span>Invested Amount</span>
                    <span>₹${formatNumber(fund.investedAmount)}</span>
                </div>
                <div class="detail-row">
                    <span>Current Value</span>
                    <span class="${getReturnClass(fund.returns)}">₹${formatNumber(fund.currentValue)}</span>
                </div>
                <div class="detail-row">
                    <span>Returns</span>
                    <span class="${getReturnClass(fund.returns)}">${formatReturns(fund.returns)}</span>
                </div>
            </div>
        </div>
    `).join('');

    // Render Stocks
    const stocksGrid = document.querySelector('#stocks .investment-grid');
    stocksGrid.innerHTML = investments.stocks.map(stock => `
        <div class="investment-card">
            <div class="investment-header">
                <h3>${stock.name}</h3>
                <span class="badge equity">Equity</span>
            </div>
            <div class="investment-details">
                <div class="detail-row">
                    <span>Purchase Date</span>
                    <span>${formatDate(stock.purchaseDate)}</span>
                </div>
                <div class="detail-row">
                    <span>Quantity</span>
                    <span>${stock.quantity} shares</span>
                </div>
                <div class="detail-row">
                    <span>Purchase Price</span>
                    <span>₹${formatNumber(stock.purchasePrice)}/share</span>
                </div>
                <div class="detail-row">
                    <span>Current Value</span>
                    <span class="${getReturnClass(stock.returns)}">₹${formatNumber(stock.currentValue)}</span>
                </div>
                <div class="detail-row">
                    <span>Returns</span>
                    <span class="${getReturnClass(stock.returns)}">${formatReturns(stock.returns)}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Modal Handling
function openNewInvestmentModal() {
    const modal = document.getElementById('investmentModal');
    modal.style.display = 'block';
    resetForm();
}

function closeInvestmentModal() {
    const modal = document.getElementById('investmentModal');
    modal.style.display = 'none';
}

// Form Handling
function toggleInvestmentFields() {
    const type = document.querySelector('select[name="type"]').value;
    const stockFields = document.querySelectorAll('.stock-field');
    const amountField = document.querySelector('.amount-field');

    stockFields.forEach(field => {
        field.style.display = type === 'stock' ? 'block' : 'none';
    });
    amountField.style.display = type === 'mutual_fund' ? 'block' : 'none';
}

document.querySelector('.investment-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        type: this.querySelector('select[name="type"]').value,
        name: this.querySelector('input[name="name"]').value,
        purchaseDate: this.querySelector('input[name="purchase_date"]').value,
        ...(this.querySelector('select[name="type"]').value === 'mutual_fund' 
            ? { amount: parseFloat(this.querySelector('input[name="amount"]').value) }
            : {
                quantity: parseInt(this.querySelector('input[name="quantity"]').value),
                pricePerShare: parseFloat(this.querySelector('input[name="price_per_share"]').value)
            }
        )
    };

    await saveInvestment(formData);
    closeInvestmentModal();
    loadInvestments();
});

// Portfolio Summary
function updatePortfolioSummary() {
    const summary = calculatePortfolioSummary();
    
    document.querySelector('.portfolio-summary').innerHTML = `
        <div class="summary-card">
            <h3>Total Investment</h3>
            <p class="amount">₹${formatNumber(summary.total)}</p>
            <span class="trend ${getReturnClass(summary.totalReturns)}">
                ${formatReturns(summary.totalReturns)} Overall
            </span>
        </div>
        <div class="summary-card">
            <h3>Mutual Funds</h3>
            <p class="amount">₹${formatNumber(summary.mutualFunds)}</p>
            <span class="trend ${getReturnClass(summary.mfReturns)}">
                ${formatReturns(summary.mfReturns)} Returns
            </span>
        </div>
        <div class="summary-card">
            <h3>Stocks</h3>
            <p class="amount">₹${formatNumber(summary.stocks)}</p>
            <span class="trend ${getReturnClass(summary.stockReturns)}">
                ${formatReturns(summary.stockReturns)} Returns
            </span>
        </div>
    `;
}

// Utility Functions
function formatNumber(num) {
    return num.toLocaleString('en-IN');
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

function formatReturns(returns) {
    return `${returns >= 0 ? '+' : ''}${returns.toFixed(1)}%`;
}

function getReturnClass(returns) {
    return returns >= 0 ? 'positive' : 'negative';
}

function resetForm() {
    document.querySelector('.investment-form').reset();
    toggleInvestmentFields();
}

// API Calls
async function saveInvestment(investmentData) {
    try {
        // Replace with actual API call
        const response = await fetch('/api/investments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(investmentData)
        });
        
        if (!response.ok) throw new Error('Failed to save investment');
        
        return await response.json();
    } catch (error) {
        console.error('Error saving investment:', error);
        alert('Failed to save investment. Please try again.');
    }
}

function calculatePortfolioSummary() {
    // Replace with actual calculations from your data
    return {
        total: 500000,
        totalReturns: 15.2,
        mutualFunds: 300000,
        mfReturns: 12.5,
        stocks: 200000,
        stockReturns: 18.7
    };
}