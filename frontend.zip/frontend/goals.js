document.addEventListener('DOMContentLoaded', function() {
    loadLoanGoals();
    loadAvailableLoans();
    updateLoanSummary();
});

async function loadLoanGoals() {
    // Example loan goals data (replace with API call)
    const loanGoals = [
        {
            id: 1,
            loanId: 1,
            loanName: "Home Loan",
            loanType: "Mortgage",
            targetAmount: 1000000,
            paidAmount: 400000,
            targetDate: "2024-12-31",
            frequency: "monthly",
            monthlyPayment: 25000,
            remainingMonths: 24
        },
        // More loan goals...
    ];

    renderLoanGoals(loanGoals);
}

function renderLoanGoals(goals) {
    const goalsGrid = document.querySelector('.goals-grid');
    goalsGrid.innerHTML = goals.map(goal => `
        <div class="loan-goal-card">
            <div class="loan-info">
                <h3>${goal.loanName}</h3>
                <span class="loan-type">${goal.loanType}</span>
            </div>
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${calculateProgress(goal)}%"></div>
                </div>
                <div class="progress-stats">
                    <span>₹${formatNumber(goal.paidAmount)}</span>
                    <span>${calculateProgress(goal)}%</span>
                    <span>₹${formatNumber(goal.targetAmount)}</span>
                </div>
            </div>
            <div class="goal-details">
                <div class="detail-item">
                    <span>Monthly Payment:</span>
                    <span>₹${formatNumber(goal.monthlyPayment)}</span>
                </div>
                <div class="detail-item">
                    <span>Remaining Months:</span>
                    <span>${goal.remainingMonths}</span>
                </div>
                <div class="detail-item">
                    <span>Target Date:</span>
                    <span>${formatDate(goal.targetDate)}</span>
                </div>
                <div class="detail-item">
                    <span>Frequency:</span>
                    <span>${capitalizeFirst(goal.frequency)}</span>
                </div>
            </div>
            <div class="goal-actions">
                <button class="btn-icon" onclick="editLoanGoal(${goal.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon" onclick="deleteLoanGoal(${goal.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

async function loadAvailableLoans() {
    // Fetch active loans for the dropdown
    const loans = await fetchLoans();
    const loanSelect = document.querySelector('select[name="loan_id"]');
    
    loanSelect.innerHTML = `
        <option value="">Choose Loan</option>
        ${loans.map(loan => `
            <option value="${loan.id}">${loan.name} - ₹${formatNumber(loan.amount)}</option>
        `).join('')}
    `;
}

function updateLoanSummary() {
    const summary = calculateLoanSummary();
    
    document.querySelector('.goals-summary').innerHTML = `
        <div class="summary-card">
            <div class="summary-icon">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="summary-info">
                <h3>Total Loan Amount</h3>
                <p>₹${formatNumber(summary.totalAmount)}</p>
            </div>
        </div>
        <div class="summary-card">
            <div class="summary-icon">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="summary-info">
                <h3>Amount Paid</h3>
                <p>₹${formatNumber(summary.amountPaid)}</p>
            </div>
        </div>
        <div class="summary-card">
            <div class="summary-icon">
                <i class="fas fa-percentage"></i>
            </div>
            <div class="summary-info">
                <h3>Overall Progress</h3>
                <p>${summary.progress}%</p>
            </div>
        </div>
    `;
}

// Form Handling
document.querySelector('.goal-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        loanId: this.querySelector('select[name="loan_id"]').value,
        targetAmount: parseFloat(this.querySelector('input[name="target_amount"]').value),
        targetDate: this.querySelector('input[name="target_date"]').value,
        frequency: this.querySelector('select[name="frequency"]').value
    };

    await saveLoanGoal(formData);
    closeGoalModal();
    loadLoanGoals();
});

// Utility Functions
function calculateProgress(goal) {
    return Math.round((goal.paidAmount / goal.targetAmount) * 100);
}

function formatNumber(num) {
    return num.toLocaleString('en-IN');
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function calculateLoanSummary() {
    // Replace with actual calculations from your data
    return {
        totalAmount: 1500000,
        amountPaid: 500000,
        progress: 33.33
    };
}

// API Integration (replace with actual endpoints)
async function fetchLoans() {
    try {
        const response = await fetch('/api/loans');
        return await response.json();
    } catch (error) {
        console.error('Error fetching loans:', error);
        return [];
    }
}

async function saveLoanGoal(goalData) {
    try {
        const response = await fetch('/api/loan-goals', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(goalData)
        });
        return await response.json();
    } catch (error) {
        console.error('Error saving loan goal:', error);
        alert('Failed to save loan goal. Please try again.');
    }
}